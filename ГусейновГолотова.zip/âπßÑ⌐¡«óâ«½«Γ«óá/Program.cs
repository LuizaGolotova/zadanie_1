﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp10
{
    class Program
    {
        static void Main(string[] args)
        {
           
          int  a = 101;
            int b = 0;
            int c = 3;
            Console.WriteLine("a = 101 ",a);
            Console.WriteLine("b = 0 ",b);
            Console.WriteLine("c = 3",c);
            int d = (a + b) / c;
            Console.WriteLine("d = (a+b)/c");
            
            Console.WriteLine($"d = {d}");
            Console.ReadLine();
            
        }
    }
}
